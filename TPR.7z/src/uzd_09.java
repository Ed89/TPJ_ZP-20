import java.util.Arrays;

public class uzd_09 {
    public static void main(String[] args) {
        int[] kiekis = {23, 45, 12, 3, 78, 98, 15, -3};
        int[] naujas = new int[0];

        System.out.print("Pradinis masyvas: ");
        for (int i = 0; i < kiekis.length; i++) {
            if (i > 0) {
                System.out.print(",");
            }
            System.out.print(kiekis[i]);
        }
        System.out.println();
        System.out.print("Patrinktu skaiciu masyvas: ");
        for (int q = 0; q < kiekis.length; q++) {

            if (kiekis[q] % 2 == 0) {
                naujas = new int[kiekis[q]];
                if (q > 2) {
                    System.out.print(",");
                }
                System.out.print(kiekis[q]);
            }
        }
    }
}

