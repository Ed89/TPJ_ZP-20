import java.util.Scanner;

public class uzd_07 {
    public static void main(String[] args) {
        Scanner reader = new Scanner(System.in);
        System.out.print("Kiek dalyvavo begikiu: ");
        int kiekis = reader.nextInt();

        int count = 0;
        int a[] = new int[kiekis];
        int minValue = 0;
        for (int i = 0; i < kiekis; i++) {
            System.out.print("Iveskite " + (i + 1) + " begiko laika: ");
            a[i] = reader.nextInt();

            count = count + a[i];
        }
        for (int q = 1; q < a.length; q++) {
            minValue = a[0];
            if (a[q] < minValue) {
                minValue = a[q];
            }
        }
        int avg = count / a.length;
        System.out.println("Greiciausio begiko laikas: " + minValue);
        System.out.println("Jis buvo: " + (avg - minValue) + " sek geresnis uz vidurki");

    }
}
