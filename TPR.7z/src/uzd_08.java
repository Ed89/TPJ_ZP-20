import java.util.Scanner;

public class uzd_08 {
    public static void main(String[] args) {
//        Scanner reader = new Scanner(System.in);
//        System.out.print("Kiek dalyvavo begikiu: ");
//        int kiekis = reader.nextInt();
        double[] kiekis = {102.56, 215.72, 99.21, 200, 175.99, 214.99};
        double count = 0;
        //double a[] = new double[kiekis];
     //   int minValue = 0;
        for (int i = 0; i < kiekis.length; i++) {
//            System.out.print("Iveskite " + (i + 1) + " begiko laika: ");
//            a[i] = reader.nextInt();

            count = count + kiekis[i];
        }

        double avg = count / kiekis.length;

        System.out.println("Vidutiniskai viena preke kainavo " + String.format("%.2f", avg)   + " Eur");
        System.out.println("Per diena pardave prekiu uz " + count);

    }
}
