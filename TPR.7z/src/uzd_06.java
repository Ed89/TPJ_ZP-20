import java.util.Scanner;

public class uzd_06 {
    public static void main(String[] args) {
        Scanner reader = new Scanner(System.in);
        System.out.print("Kiek egliuciu atvezta ");
        int kiekis = reader.nextInt();
        int count =0;
        for(int i=1; i<=kiekis; i++){
            System.out.print("Iveskite "+i+" aglutes auksti: ");
            int auks = reader.nextInt();
            count += auks;
        }
        System.out.print("Eglutes aukscio vidurkis: "+(float)count/kiekis+" cm");
    }
}
