public class uzd_10 {
    public static void main(String[] args) {
        double[] kiekis = {824.25, 1225.12, 459.16, 1500};
        double[] naujas = new double[0];

        System.out.print("Atlyginimas iki: ");
        for (int i = 0; i < kiekis.length; i++) {

            if (i > 0) {
                System.out.print(",");
            }
            System.out.print(kiekis[i]);

        }
        System.out.println();
        System.out.print("Atlyginimas po: ");
        for (int q = 0; q < kiekis.length; q++) {

            if (kiekis[q] < 1000) {
                if (q > 0) {
                    System.out.print(", ");
                }
                System.out.print(String.format("%.2f", kiekis[q] * 1.10));
            } else {
                if (q > 0) {
                    System.out.print(", ");
                }
                System.out.print(String.format("%.2f", kiekis[q] * 1.05));
            }
        }
    }
}
